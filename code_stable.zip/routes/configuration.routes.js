const router = require("express").Router();
const { body, query, validationResult } = require("express-validator");
const ctrl = require("../controllers/configuration.controller");
const { requireAuth, requirePermission } = require("../middleware/auth.middleware");

/* -------------------------------------------
 * Helper validation
 * -----------------------------------------*/
const handleValidation = (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res
            .status(400)
            .json({ message: "Erreurs de validation.", code: "VALIDATION_ERROR", errors: errors.array() });
    }
    next();
};

/**
 * @swagger
 * tags:
 *   name: Configurations
 *   description: Gestion des configurations applicatives (clé/valeur)
 */

/**
 * @swagger
 * /api/configurations:
 *   get:
 *     summary: Liste les configurations
 *     tags: [Configurations]
 *     security: [ { bearerAuth: [] } ]
 *     parameters:
 *       - in: query
 *         name: prefix
 *         schema:
 *           type: string
 *         description: "Filtrer les clés par préfixe (ex: \"smtp.\", \"billing.\")"
 *       - $ref: '#/components/parameters/page'
 *       - $ref: '#/components/parameters/limit'
 *     responses:
 *       200:
 *         description: OK
 *       500:
 *         description: Erreur serveur
 */

router.get(
    "/",
    requireAuth,
    requirePermission("config.read"), [
        query("search").optional().isString().trim(),
        query("prefix").optional().isString().trim(),
    ],
    handleValidation,
    ctrl.list
);

/**
 * @swagger
 * /api/configurations:
 *   post:
 *     summary: Crée ou met à jour une configuration (upsert)
 *     tags: [Configurations]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpsertConfiguration'
 *     responses:
 *       200:
 *         description: Configuration mise à jour
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: "Configuration enregistrée"
 *                 item:
 *                   $ref: '#/components/schemas/Configuration'
 *       201:
 *         description: Configuration créée
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: "Configuration créée"
 *                 item:
 *                   $ref: '#/components/schemas/Configuration'
 *       400:
 *         description: Erreurs de validation
 *       500:
 *         description: Erreur serveur
 */
router.post(
    "/",
    requireAuth,
    requirePermission("config.manage"), [
        body("key").isString().notEmpty().trim(),
        // on accepte value string OU jsonValue objet/array pour plus de souplesse
        body("value").optional().isString(),
        body("jsonValue").optional().custom((v) => typeof v === "object"),
        body().custom((body) => {
            if (body.value === undefined && body.jsonValue === undefined) {
                throw new Error('Fournir "value" (string) ou "jsonValue" (objet)');
            }
            return true;
        }),
        body("description").optional().isString().trim(),
    ],
    handleValidation,
    ctrl.upsert
);

module.exports = router;