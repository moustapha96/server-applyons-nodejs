/* prisma/seed.js */
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();


const now = () => new Date();


const CONFIGS = [
    // App
    { key: 'app.name', value: process.env.APP_NAME || 'Applyons Backoffice' },
    { key: 'app.env', value: process.env.NODE_ENV || 'development' },
    { key: 'app.baseUrl', value: process.env.APP_BASE_URL || 'http://localhost:5000' },

    // Sécurité / JWT
    { key: 'security.jwt.expiresIn', value: process.env.JWT_EXPIRES_IN || '1d' },
    { key: 'security.cookie.name', value: process.env.SESSION_COOKIE_NAME || 'jwt' },

    // SMTP
    { key: 'smtp.host', value: process.env.SMTP_HOST || 'smtp.example.com' },
    { key: 'smtp.port', value: String(process.env.SMTP_PORT || '587') },
    { key: 'smtp.user', value: process.env.SMTP_USER || 'no-reply@example.com' },
    { key: 'smtp.from', value: process.env.SMTP_FROM || 'Applyons <no-reply@example.com>' },
    // ⚠️ si tu veux seed le mot de passe, fais-le en sachant qu’il sera visible dans la DB:
    { key: 'smtp.pass', value: process.env.SMTP_PASS || '' },

    // Billing par défaut
    { key: 'billing.currency', value: process.env.BILLING_CURRENCY || 'USD' },
    { key: 'billing.country', value: process.env.BILLING_COUNTRY || 'SN' },

    // URLs publiques utiles
    { key: 'urls.frontend', value: process.env.FRONTEND_URL || 'http://localhost:5173' },
    { key: 'urls.docs', value: process.env.DOCS_URL || 'http://localhost:5000/api-docs' },
];

async function upsertConfigurations() {
    for (const c of CONFIGS) {
        await prisma.configuration.upsert({
            where: { key: c.key },
            update: { value: c.value, updatedAt: now() },
            create: { key: c.key, value: c.value, createdAt: now(), updatedAt: now() },
        });
    }
}

/* -------------------- main -------------------- */
async function main() {
    console.log('🔧 Seeding…');

    await upsertConfigurations();
    console.log('✅ Configurations: seeded', CONFIGS.length);
}

main()
    .catch((e) => {
        console.error('❌ Seed error:', e);
        process.exit(1);
    })
    .finally(async() => {
        await prisma.$disconnect();
    });