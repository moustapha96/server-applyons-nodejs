// controllers/contact.controller.js
const { PrismaClient, Prisma } = require("@prisma/client");
const { validationResult } = require("express-validator");
const emailService = require("../services/email.service");
const stringify = require("csv-stringify/sync").stringify;

const prisma = new PrismaClient();

const SORTABLE = new Set(["createdAt", "email", "name", "subject"]);
const MAX_LIMIT = 100;

const sanitizePagination = (q) => {
    const page = Math.max(1, Number(q.page || 1));
    const limit = Math.min(MAX_LIMIT, Math.max(1, Number(q.limit || 10)));
    const skip = (page - 1) * limit;
    const sortBy = SORTABLE.has(String(q.sortBy)) ? String(q.sortBy) : "createdAt";
    const sortOrder = String(q.sortOrder).toLowerCase() === "asc" ? "asc" : "desc";
    return { page, limit, skip, sortBy, sortOrder };
};

// ============ LIST ============
exports.list = async(req, res) => {
    try {
        const { email, search, dateFrom, dateTo } = req.query;
        const { page, limit, skip, sortBy, sortOrder } = sanitizePagination(req.query);

        const where = {};
        if (email) where.email = { contains: String(email), mode: "insensitive" };
        if (search) {
            where.OR = [
                { name: { contains: String(search), mode: "insensitive" } },
                { subject: { contains: String(search), mode: "insensitive" } },
                { message: { contains: String(search), mode: "insensitive" } },
            ];
        }
        if (dateFrom || dateTo) {
            where.createdAt = {};
            if (dateFrom) where.createdAt.gte = new Date(dateFrom);
            if (dateTo) where.createdAt.lte = new Date(dateTo);
        }

        const [rows, total] = await Promise.all([
            prisma.contactMessage.findMany({
                where,
                orderBy: {
                    [sortBy]: sortOrder
                },
                skip,
                take: limit,
            }),
            prisma.contactMessage.count({ where }),
        ]);

        return res.status(200).json({
            messages: rows,
            pagination: { page, limit, total, pages: Math.ceil(total / limit) },
            filters: { email: email || null, search: search || null, dateFrom: dateFrom || null, dateTo: dateTo || null, sortBy, sortOrder },
        });
    } catch (e) {
        console.error("CONTACT_LIST_ERROR:", e);
        return res.status(500).json({ message: "Échec récupération messages", code: "GET_CONTACTS_ERROR" });
    }
};

// ============ GET BY ID ============
exports.getById = async(req, res) => {
    try {
        const row = await prisma.contactMessage.findUnique({ where: { id: req.params.id } });
        if (!row) return res.status(404).json({ message: "Message introuvable", code: "CONTACT_NOT_FOUND" });
        return res.status(200).json({ message: row });
    } catch (e) {
        console.error("CONTACT_GET_ERROR:", e);
        return res.status(500).json({ message: "Échec récupération message", code: "GET_CONTACT_ERROR" });
    }
};

// ============ CREATE ============
exports.create = async(req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty())
            return res.status(400).json({ message: "Erreurs de validation", errors: errors.array() });

        const { name, email, subject, message } = req.body || {};
        const c = await prisma.contactMessage.create({
            data: {
                name: String(name).trim(),
                email: String(email).trim().toLowerCase(),
                subject: subject ? String(subject).trim() : null,
                message: String(message).trim(),
            },
        });
        // après la création du message c (prisma.contactMessage.create(...))
        try {
            await Promise.all([
                emailService.sendContactToAdmin(c), // vers l’admin/settings.contactEmail
                emailService.sendContactConfirmation(c), // vers l’expéditeur
            ]);
        } catch (e) {
            console.warn("CONTACT_EMAIL_WARN:", e.message || e);
        }

        return res.status(201).json({ message: "Message enregistré", contact: c });
    } catch (e) {
        console.error("CONTACT_CREATE_ERROR:", e);
        return res.status(500).json({ message: "Échec enregistrement message", code: "CREATE_CONTACT_ERROR" });
    }
};

// ============ DELETE (hard) ============
exports.remove = async(req, res) => {
    try {
        const { id } = req.params;
        await prisma.contactMessage.delete({ where: { id } });
        return res.status(200).json({ message: "Message supprimé" });
    } catch (e) {
        console.error("CONTACT_DELETE_ERROR:", e);
        if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2025") {
            return res.status(404).json({ message: "Message introuvable", code: "CONTACT_NOT_FOUND" });
        }
        return res.status(500).json({ message: "Échec suppression", code: "DELETE_CONTACT_ERROR" });
    }
};

// ============ PURGE older than X days ============
exports.purgeOlderThan = async(req, res) => {
    try {
        const days = Math.max(1, Number(req.query.days || 90));
        const threshold = new Date(Date.now() - days * 24 * 3600 * 1000);
        const result = await prisma.contactMessage.deleteMany({
            where: { createdAt: { lt: threshold } },
        });
        return res.status(200).json({ message: "Purge effectuée", deleted: result.count, olderThanDays: days });
    } catch (e) {
        console.error("CONTACT_PURGE_ERROR:", e);
        return res.status(500).json({ message: "Échec purge", code: "PURGE_CONTACT_ERROR" });
    }
};

// ============ EXPORT CSV ============
exports.exportCsv = async(req, res) => {
    try {
        // On réutilise les mêmes filtres que list()
        const { email, search, dateFrom, dateTo } = req.query;

        const where = {};
        if (email) where.email = { contains: String(email), mode: "insensitive" };
        if (search) {
            where.OR = [
                { name: { contains: String(search), mode: "insensitive" } },
                { subject: { contains: String(search), mode: "insensitive" } },
                { message: { contains: String(search), mode: "insensitive" } },
            ];
        }
        if (dateFrom || dateTo) {
            where.createdAt = {};
            if (dateFrom) where.createdAt.gte = new Date(dateFrom);
            if (dateTo) where.createdAt.lte = new Date(dateTo);
        }

        const rows = await prisma.contactMessage.findMany({
            where,
            orderBy: { createdAt: "desc" },
            select: { id: true, name: true, email: true, subject: true, message: true, createdAt: true },
        });

        const csv = stringify(rows.map(r => ({
            id: r.id,
            name: r.name,
            email: r.email,
            subject: r.subject || "",
            message: r.message.replace(/\r?\n/g, " ").slice(0, 5000), // éviter les retours chars sauvages
            createdAt: r.createdAt.toISOString(),
        })), { header: true });

        res.setHeader("Content-Type", "text/csv; charset=utf-8");
        res.setHeader("Content-Disposition", `attachment; filename="contacts_export_${Date.now()}.csv"`);
        return res.status(200).send(csv);
    } catch (e) {
        console.error("CONTACT_EXPORT_CSV_ERROR:", e);
        return res.status(500).json({ message: "Échec export CSV", code: "EXPORT_CSV_ERROR" });
    }
};

// ============ STATS (mensuel + domaines d'email) ============
exports.stats = async(req, res) => {
    try {
        const [monthly, byDomain] = await Promise.all([
            prisma.$queryRaw `
        SELECT date_trunc('month', "createdAt") AS month, COUNT(*)::int AS total
        FROM "ContactMessage"
        GROUP BY month
        ORDER BY month ASC
      `,
            prisma.$queryRaw `
        SELECT split_part("email", '@', 2) AS domain, COUNT(*)::int AS total
        FROM "ContactMessage"
        GROUP BY domain
        ORDER BY total DESC
        LIMIT 20
      `,
        ]);

        return res.status(200).json({
            monthly: monthly.map((r) => ({ month: r.month, total: Number(r.total) })),
            byDomain: byDomain.map((r) => ({ domain: r.domain || "(unknown)", total: Number(r.total) })),
        });
    } catch (e) {
        console.error("CONTACT_STATS_ERROR:", e);
        return res.status(500).json({ message: "Échec stats", code: "CONTACT_STATS_ERROR" });
    }
};