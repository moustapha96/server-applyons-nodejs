// controllers/configuration.controller.js
const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

exports.list = async(_req, res) => {
    try {
        const rows = await prisma.configuration.findMany({ orderBy: { createdAt: "desc" } });
        return res.status(200).json({ configurations: rows });
    } catch (e) {
        console.error("CFG_LIST_ERROR:", e);
        return res.status(500).json({ message: "Échec récupération configurations", code: "GET_CFG_ERROR" });
    }
};

exports.upsert = async(req, res) => {
    try {
        const { key, value } = req.body || {};
        if (!key) return res.status(400).json({ message: "key requis" });
        const up = await prisma.configuration.upsert({
            where: { key },
            update: { value: value || null },
            create: { key, value: value || null },
        });
        return res.status(200).json({ message: "Configuration enregistrée", configuration: up });
    } catch (e) {
        console.error("CFG_UPSERT_ERROR:", e);
        return res.status(500).json({ message: "Échec upsert configuration", code: "UPSERT_CFG_ERROR" });
    }
};